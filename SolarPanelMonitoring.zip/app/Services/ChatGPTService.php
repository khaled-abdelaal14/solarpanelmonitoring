<?php

namespace App\Services;

use GuzzleHttp\Client;

class ChatGPTService
{
   
}
